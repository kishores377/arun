import React from "react";
import { useState, useEffect } from "react";
import "./Style.css";
import 'bootstrap/dist/css/bootstrap.css';
import { Navigate, useNavigate } from 'react-router-dom'
import axios from "axios";
const Login = () => {
    const navigate = useNavigate();
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [emailError, setEmailError] = useState("");
    const [data, setdata] = useState([])
    useEffect(() => {
        axios.get("http://localhost:4001/RegisterData").then((res) => {
            setdata(res?.data)
        })
            .catch((err) => {
                console.log(err)
            })
    }, [])
    const submithandle = () => {
        let flag = false
        let id;
        data?.forEach((x,k) => {
            if (x.email == email && x.password == password) {
                flag = true
                id=x.id
            }
        })
        if(flag==true){
            sessionStorage.setItem("EMAIL",id)
            navigate("/rgfrm")
        }
        else if(flag==false){
            alert("Enter correct details")
        }
    }
    const handleclick = (e) => {
        if (e.target.name = "email") {
            setEmail(e.target.value)
        }
        if (e.target.name = "password") {
            setPassword(e.target.value)
        }
    }

    return (
        <>
            <div className="row">
                <div className="col-md-4"></div>
                <div className="col-md-4">
                    <div className="cont">
                        <h1>LOGIN</h1>
                        <form onSubmit={submithandle}>
                            <div class="form-group" style={{ padding: "4px" }}>
                                <label for="exampleInputEmail1">Email address</label>
                                <input type="email" onChange={(e) => handleclick(e)} name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" />

                                {emailError}

                                {/* <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small> */}
                            </div>
                            <div class="form-group" style={{ padding: "4px" }}>
                                <label for="exampleInputPassword1">Password</label>
                                <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} name="password" class="form-control" id="exampleInputPassword1" placeholder="Password" />
                            </div>
                            <button type="submit" class="btn btn-primary" style={{ marginTop: "5px" }}>Submit</button>
                        </form>
                    </div>
                </div>
                <div className="col-md-4"></div>
            </div>
        </>
    )
}
export default Login;