import React from "react";
import { useState, useEffect } from "react";
import "./Style.css";
import 'bootstrap/dist/css/bootstrap.css';
import { useNavigate } from "react-router-dom";
import axios from "axios";
const Student = () => {
    const navigate = useNavigate();
    const handleclick = (e) => {
        e.preventDefault();
        navigate("/login")
        if (email && password) {
            const data = { email, password, firstName, lastName }
            sessionStorage.setItem("FNAME", firstName)
            axios.post("http://localhost:4001/RegisterData", data).then((res) => {
                console.log(res)
            })
                .catch((err) => {
                    console.log(err)
                })
            console.log(data)
        }
    }
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [firstName, setFirstName] = useState("");
    const [lastName, setLastName] = useState("");
    // useEffect(()=>{
    //     sessionStorage.setItem("FNAME",firstName)
    // },[])
    return (
        <>
            <div className="row">
                <div className="col-md-4"></div>
                <div className="col-md-4">
                    <div className="cont">
                        <h1>REGISTER</h1>
                        <form onSubmit={handleclick}>
                            <div class="form-group" style={{ padding: "4px" }}>
                                <label for="formGroupExampleInput">First Name</label>
                                <input type="text" value={firstName} class="form-control" id="formGroupExampleInput" placeholder="Enter FirstName" onChange={(e) => setFirstName(e.target.value)} />
                            </div>
                            <div class="form-group" style={{ padding: "4px" }}>
                                <label for="formGroupExampleInput">Last Name</label>
                                <input type="text" value={lastName} onChange={(e) => setLastName(e.target.value)} class="form-control" id="formGroupExampleInput" placeholder="Enter LastName" />
                            </div>
                            <div class="form-group" style={{ padding: "4px" }}>
                                <label for="exampleInputEmail1">Email address</label>
                                <input type="email" value={email} class="form-control" onChange={(e) => setEmail(e.target.value)} id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" />
                                {/* <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small> */}
                            </div>
                            <div class="form-group" style={{ padding: "4px" }}>
                                <label for="exampleInputPassword1">Create Password</label>
                                <input type="password" value={password} class="form-control" onChange={(e) => setPassword(e.target.value)} id="exampleInputPassword1" placeholder="Password" />
                            </div>
                            <button type="submit" class="btn btn-primary" style={{ marginTop: "5px" }}>Submit</button>
                        </form>
                    </div>
                </div>
                <div className="col-md-4"></div>
            </div>
            {/* <center> */}
            {/* <h1>Register</h1>
            <div className="container">

                <label>First Name</label>
                <div>
                    <input type="text" vlaue="text"></input>
                </div>
                <label>Last Name</label>
                <div>
                    <input type="text" vlaue="text"></input>
                </div>
                <label>Email</label>
                <div>
                    <input type="email" vlaue="text"></input>
                </div>
                <label>Password</label>
                <div>
                    <input type="password" vlaue=""></input>
                </div>
            </div>
            {/* </center>
 */}
        </>
    )
}
export default Student;