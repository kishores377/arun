import axios from "axios";
import React, { useEffect, useState } from "react";
import 'bootstrap/dist/css/bootstrap.css';

const RegForm = () => {
    const submithandle = (e) => {
        {
            e.preventDefault();
            if (fname || lname || email || emid || altemail || pname || marks || percentage || college || univer || city || state) {
                const data = { fname, lname, email, emid, altemail, pname, marks, percentage, college, univer, city, state }
                axios.post("http://localhost:4000/Studentdetails", data).then((res) => {
                    console.log(res.data)
                })
                    .catch((err) => {
                        console.log(err)
                    })
                console.log(data)
            }
        }
    }
    useEffect(() => {
        let loginid = sessionStorage.getItem("EMAIL")
        axios.get("http://localhost:4001/RegisterData").then((res) => {
            let d = res?.data
            let data=d.filter((x)=>x.id==loginid)
            if (loginid && data) {
                let a = data[0]
                setEmail(a.email);
                setFname(a.firstName);
                setLname(a.lastName);
            }
        })
            .catch((err) => {
                console.log(err)
            })

        // alert(typeof(+email1),"shshs")
        // let Fname1=sessionStorage.getItem("FNAME")

    }, [])
    const [fname, setFname] = useState();
    const [lname, setLname] = useState();
    const [email, setEmail] = useState();
    const [emid, setEmid] = useState();
    const [altemail, setAltemail] = useState();
    const [pname, setPname] = useState();
    const [bname, setBname] = useState();
    const [grade, setGrade] = useState();
    const [marks, setMarks] = useState();
    const [percentage, setpercentage] = useState();
    const [college, setCollege] = useState();
    const [univer, setUniver] = useState();
    const [city, setCity] = useState();
    const [state, setState] = useState();
    return (
        <>
            <div className="container ">
                <center className="mt-5">
                    <div>
                        <h1>STUDENT DETAILS</h1>
                        <h1>{fname} {lname}</h1>
                    </div>
                    <form style={{ width: "50%", marginTop: "3%" }} onSubmit={submithandle}>
                        <div className="row">
                            <div className="col-md-6">
                                <div className="form-group mb-3">
                                    <label htmlFor="formGroupExampleInput" >First Name</label>
                                    <input type="text" className="form-control" disabled value={fname} onChange={(e) => setFname(e.target.value)} id="formGroupExampleInput" placeholder="Example input" />
                                </div>
                                <div className="form-group mb-3">
                                    <label htmlFor="formGroupExampleInput2">Email ID</label>
                                    <input type="text" className="form-control" disabled value={email} id="formGroupExampleInput2" placeholder="Another input" />
                                </div>
                                <div className="form-group mb-3">
                                    <label htmlFor="exampleInputEmail1">Alternate Email</label>
                                    <input type="email" className="form-control" value={altemail} onChange={(e) => setAltemail(e.target.value)} id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" />
                                </div>
                                <div className="form-group mb-3">
                                    <div class="dropdown">
                                        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            BRANCH
                                        </button>
                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton" onChange={(e) => setBname(e.target.value)} >
                                            <a class="dropdown-item" href="#">CSE</a>
                                            <a class="dropdown-item" href="#">ECE</a>
                                            <a class="dropdown-item" href="#">EEE</a>
                                            <a class="dropdown-item" href="#">CIVIL</a>
                                        </div>
                                    </div>
                                    <div className="mt-3">
                                        <label htmlFor="formGroupExampleInput2"  >Marks</label>
                                        <input type="text" className="form-control" value={marks} onChange={(e) => setMarks(e.target.value)} id="formGroupExampleInput2" placeholder="Another input" />
                                    </div>
                                    <div className="mt-3">
                                        <label htmlFor="formGroupExampleInput2" >college</label>
                                        <input type="text" className="form-control" value={college} onChange={(e) => setCollege(e.target.value)} id="formGroupExampleInput2" placeholder="Another input" />
                                    </div>
                                    <div className="mt-3">
                                        <label htmlFor="formGroupExampleInput2">City</label>
                                        <input type="text" className="form-control" value={city} onChange={(e) => setCity(e.target.value)} id="formGroupExampleInput2" placeholder="Another input" />
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-6">
                                <div className="form-group mb-3">
                                    <label htmlFor="formGroupExampleInput2">Last Name</label>
                                    <input type="text" className="form-control" value={lname} disabled id="formGroupExampleInput2" placeholder="Another input" />
                                </div>
                                <div className="form-group mb-3">
                                    <label htmlFor="formGroupExampleInput2">Emp Id</label>
                                    <input type="text" className="form-control" value={emid} onChange={(e) => setEmid(e.target.value)} id="formGroupExampleInput2" placeholder="Another input" />
                                </div>
                                <div className="form-group mb-3">
                                    <label htmlFor="formGroupExampleInput2">Parent/Guardian Name</label>
                                    <input type="text" className="form-control" value={pname} onChange={(e) => setPname(e.target.value)} id="formGroupExampleInput2" placeholder="Another input" />
                                </div>

                                <div class="dropdown">
                                    <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        GRADE
                                    </button>
                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton" onChange={(e) => setGrade(e.target.value)}>
                                        <a class="dropdown-item" href="#">A</a>
                                        <a class="dropdown-item" href="#">B</a>
                                        <a class="dropdown-item" href="#">C</a>
                                        <a class="dropdown-item" href="#">F</a>


                                    </div>
                                </div>
                                {/* <div className="row"> */}
                                {/* <div className="form-group mb-3" style={{ dispaly: "flex" }}> */}
                                <div className="row " style={{ dispaly: "flex" }}>
                                    {/* <div > */}

                                    <div className="mt-3">
                                        <label htmlFor="formGroupExampleInput2">Percentage</label>
                                        <input type="text" className="form-control" value={percentage} onChange={(e) => setpercentage(e.target.value)} id="formGroupExampleInput2" placeholder="Another input" />
                                    </div>
                                    <div className="mt-3">
                                        <label htmlFor="formGroupExampleInput2">University Affiliated</label>
                                        <input type="text" className="form-control" value={univer} onChange={(e) => setUniver(e.target.value)} id="formGroupExampleInput2" placeholder="Another input" />
                                    </div>
                                    <div className="mt-3">
                                        <label htmlFor="formGroupExampleInput2">State</label>
                                        <input type="text" className="form-control" value={state} onChange={(e) => setState(e.target.value)} id="formGroupExampleInput2" placeholder="Another input" />
                                    </div>
                                    {/* </div> */}
                                </div>
                                {/* </div> */}
                                {/* </div> */}
                            </div>
                        </div>
                        {/* Additional form groups go here */}
                        <button type="submit" className="btn btn-primary mt-4">Submit</button>
                    </form>
                </center>
            </div>


        </>
    )
}
export default RegForm;