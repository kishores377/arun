import logo from './logo.svg';
import './App.css';
import Student from './Components/Register';
import Login from './Components/Login';
import { BrowserRouter, Routes,Route } from 'react-router-dom';
import RegForm from './Components/Studentform';

function App() {
  return (
<div>
  <BrowserRouter>
  <Routes>
    <Route path="/" element={<Student/>}/>
    <Route path="/login" element={<Login/>}/>
    <Route path="/rgfrm" element={<RegForm/>}/>

  </Routes>                                                  
  </BrowserRouter>
</div>
  );
}

export default App;
